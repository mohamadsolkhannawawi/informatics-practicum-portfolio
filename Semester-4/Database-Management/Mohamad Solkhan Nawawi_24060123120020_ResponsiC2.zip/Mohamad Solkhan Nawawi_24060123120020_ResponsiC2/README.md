# Responsi Manajemen Basis Data

**Soal responsi ada di file BTree.cpp, silahkan dikerjakan sebaik mungkin**

# Petunjuk
- **Jangan ubah kode selain yang diperintahkan**
- **Terdapat dua cara untuk melakukan testing jika sudah selesai mengerjakan**
  1. untuk sekedar run program, tulis command ini di terminal "g++ -std=c++17 -Wall -Wextra -O2 main.cpp Node.cpp BTree.cpp -o btree_demo"
  2. lalu "./btree_demo"
  3. untuk melakukan test, tulis command ini di terminal "g++ -std=c++17 -Wall -Wextra -O2 test_btree.cpp Node.cpp BTree.cpp -o test" 
  4. lalu "./test"

# Pengumpulan
- **Terserah asprak**
