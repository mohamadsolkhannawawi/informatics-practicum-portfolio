#ifndef ARENA_C
#define ARENA_C

#include "arena.h"
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <GL/glut.h>

// Arena properties
static float arenaSize = 30.0f;
static float wallHeight = 5.0f;

// Camera properties
static float posX = 0.0f;
static float posY = 2.0f;
static float posZ = 15.0f;
static float lookX = 0.0f;
static float lookY = 0.0f;
static float lookZ = 0.0f;
static float angleX = 0.0f;
static float angleY = 0.0f;

// Buildings collection
static std::vector<Building> buildings;

// Warna-warna untuk gedung
static Color colors[] = {
    {0.8f, 0.8f, 0.8f}, // Abu-abu muda
    {0.7f, 0.7f, 0.8f}, // Abu-abu kebiruan
    {0.6f, 0.6f, 0.7f}, // Abu-abu tua
    {0.8f, 0.8f, 0.7f}, // Cream
    {0.7f, 0.8f, 0.7f}  // Abu-abu kehijauan
};

// Fungsi untuk menambahkan gedung ke vektor
static void addBuilding(float x, float z, float width, float depth, float height, Color color) {
    Building b = {x, z, width, depth, height, color};
    buildings.push_back(b);
}

// Fungsi untuk membuat gedung
static void drawBuilding(float x, float z, float width, float depth, float height, Color color) {
    glPushMatrix();
    glTranslatef(x, height/2, z);
    glColor3f(color.r, color.g, color.b);
    
    // Gedung utama
    glPushMatrix();
    glScalef(width, height, depth);
    glutSolidCube(1.0);
    glPopMatrix();
    
    // Garis-garis untuk jendela
    glColor3f(0.1f, 0.1f, 0.2f);
    float windowSize = 0.15f;
    float spacing = 0.4f;
    
    // Jendela depan
    for (float wx = -width/2 + spacing; wx < width/2; wx += spacing) {
        for (float wy = -height/2 + spacing; wy < height/2; wy += spacing) {
            glPushMatrix();
            glTranslatef(wx, wy, depth/2 + 0.01f);
            glScalef(windowSize, windowSize, 0.01f);
            glutSolidCube(1.0);
            glPopMatrix();
        }
    }
    
    // Jendela belakang
    for (float wx = -width/2 + spacing; wx < width/2; wx += spacing) {
        for (float wy = -height/2 + spacing; wy < height/2; wy += spacing) {
            glPushMatrix();
            glTranslatef(wx, wy, -depth/2 - 0.01f);
            glScalef(windowSize, windowSize, 0.01f);
            glutSolidCube(1.0);
            glPopMatrix();
        }
    }
    
    // Jendela samping kiri
    for (float wz = -depth/2 + spacing; wz < depth/2; wz += spacing) {
        for (float wy = -height/2 + spacing; wy < height/2; wy += spacing) {
            glPushMatrix();
            glTranslatef(-width/2 - 0.01f, wy, wz);
            glScalef(0.01f, windowSize, windowSize);
            glutSolidCube(1.0);
            glPopMatrix();
        }
    }
    
    // Jendela samping kanan
    for (float wz = -depth/2 + spacing; wz < depth/2; wz += spacing) {
        for (float wy = -height/2 + spacing; wy < height/2; wy += spacing) {
            glPushMatrix();
            glTranslatef(width/2 + 0.01f, wy, wz);
            glScalef(0.01f, windowSize, windowSize);
            glutSolidCube(1.0);
            glPopMatrix();
        }
    }
    
    glPopMatrix();
}

// Fungsi untuk menggambar tembok arena
static void drawWalls() {
    float boundarySize = arenaSize / 2;
    float wallThickness = 1.0f;
    
    glColor3f(0.5f, 0.5f, 0.5f); // Warna tembok
    
    // Tembok selatan
    glPushMatrix();
    glTranslatef(0.0f, wallHeight/2, boundarySize + wallThickness/2);
    glScalef(arenaSize + wallThickness*2, wallHeight, wallThickness);
    glutSolidCube(1.0);
    glPopMatrix();
    
    // Tembok utara
    glPushMatrix();
    glTranslatef(0.0f, wallHeight/2, -boundarySize - wallThickness/2);
    glScalef(arenaSize + wallThickness*2, wallHeight, wallThickness);
    glutSolidCube(1.0);
    glPopMatrix();
    
    // Tembok timur
    glPushMatrix();
    glTranslatef(boundarySize + wallThickness/2, wallHeight/2, 0.0f);
    glScalef(wallThickness, wallHeight, arenaSize);
    glutSolidCube(1.0);
    glPopMatrix();
    
    // Tembok barat
    glPushMatrix();
    glTranslatef(-boundarySize - wallThickness/2, wallHeight/2, 0.0f);
    glScalef(wallThickness, wallHeight, arenaSize);
    glutSolidCube(1.0);
    glPopMatrix();
}

// Fungsi untuk menggambar jalan
static void drawRoad() {
    glPushMatrix();
    glColor3f(0.2f, 0.2f, 0.2f);
    glTranslatef(0.0f, -0.05f, 0.0f);
    glScalef(arenaSize, 0.1f, arenaSize);
    glutSolidCube(1.0);
    glPopMatrix();
    
    // Marka jalan
    glPushMatrix();
    glColor3f(1.0f, 1.0f, 1.0f);
    glTranslatef(0.0f, 0.01f, 0.0f);
    
    // Jalan horizontal
    glPushMatrix();
    glTranslatef(0.0f, 0.0f, 0.0f);
    glScalef(arenaSize-10.0f, 0.01f, 0.5f);
    glutSolidCube(1.0);
    glPopMatrix();
    
    // Jalan vertikal
    glPushMatrix();
    glTranslatef(0.0f, 0.0f, 0.0f);
    glScalef(0.5f, 0.01f, arenaSize-10.0f);
    glutSolidCube(1.0);
    glPopMatrix();
    
    glPopMatrix();
}

// Initialize the arena
void initArena() {
    // Clear any existing buildings
    buildings.clear();
    
    // Add buildings to the arena
    // Kuadran 1
    addBuilding(5.0f, 5.0f, 3.0f, 2.0f, 8.0f, colors[0]);
    addBuilding(8.0f, 3.0f, 2.0f, 2.0f, 6.0f, colors[1]);
    addBuilding(3.0f, 8.0f, 2.0f, 3.0f, 5.0f, colors[2]);
    
    // Kuadran 2
    addBuilding(-5.0f, 5.0f, 2.5f, 2.5f, 7.0f, colors[3]);
    addBuilding(-8.0f, 3.0f, 3.0f, 2.0f, 4.0f, colors[4]);
    addBuilding(-4.0f, 8.0f, 2.0f, 2.0f, 9.0f, colors[0]);
    
    // Kuadran 3
    addBuilding(-5.0f, -5.0f, 3.0f, 3.0f, 6.0f, colors[1]);
    addBuilding(-8.0f, -3.0f, 2.0f, 2.0f, 8.0f, colors[2]);
    addBuilding(-3.0f, -7.0f, 2.5f, 2.5f, 5.0f, colors[3]);
    
    // Kuadran 4
    addBuilding(5.0f, -5.0f, 2.0f, 3.0f, 7.5f, colors[4]);
    addBuilding(8.0f, -3.0f, 3.0f, 2.0f, 5.5f, colors[0]);
    addBuilding(3.0f, -8.0f, 2.5f, 2.5f, 6.5f, colors[1]);
    
    // Gedung tinggi di tengah
    addBuilding(0.0f, 0.0f, 4.0f, 4.0f, 12.0f, colors[2]);
}

// Draw the entire arena
void drawArena() {
    // Draw the ground/road
    drawRoad();
    
    // Draw walls
    drawWalls();
    
    // Draw all buildings
    for (size_t i = 0; i < buildings.size(); i++) {
        Building b = buildings[i];
        drawBuilding(b.x, b.z, b.width, b.depth, b.height, b.color);
    }
}

// Check collision with buildings and walls
bool checkCollision(float x, float y, float z, float radius) {
    // Check collision with buildings
    for (size_t i = 0; i < buildings.size(); i++) {
        Building b = buildings[i];
        
        // Calculate closest point on the building to the object
        float closestX = fmax(b.x - b.width/2, fmin(x, b.x + b.width/2));
        float closestZ = fmax(b.z - b.depth/2, fmin(z, b.z + b.depth/2));
        
        // Check if closest point is within collision radius
        float distanceX = x - closestX;
        float distanceZ = z - closestZ;
        float distanceSquared = distanceX * distanceX + distanceZ * distanceZ;
        
        if (distanceSquared < radius * radius) {
            return true; // Collision detected
        }
    }
    
    // Check collision with arena boundaries
    float boundarySize = arenaSize / 2;
    if (x - radius < -boundarySize || x + radius > boundarySize || 
        z - radius < -boundarySize || z + radius > boundarySize) {
        return true; // Collision with walls
    }
    
    return false; // No collision detected
}

// Set camera position
void setCameraPosition(float x, float y, float z) {
    posX = x;
    posY = y;
    posZ = z;
    updateCameraLook(angleX, angleY);
}

// Update camera view direction based on angles
void updateCameraLook(float newAngleX, float newAngleY) {
    angleX = newAngleX;
    angleY = newAngleY;
    
    // Convert angles to radians
    float angleXRad = angleX * 3.14159f / 180.0f;
    float angleYRad = angleY * 3.14159f / 180.0f;
    
    // Calculate look-at point based on angles
    lookX = posX + sin(angleYRad) * cos(angleXRad);
    lookY = posY + sin(angleXRad);
    lookZ = posZ - cos(angleYRad) * cos(angleXRad);
}

// Get camera position
void getCameraPosition(float* x, float* y, float* z) {
    *x = posX;
    *y = posY;
    *z = posZ;
}

// Get camera look-at point
void getCameraLookAt(float* x, float* y, float* z) {
    *x = lookX;
    *y = lookY;
    *z = lookZ;
}

// Draw text on screen
void drawArenaText(float x, float y, const char* text) {
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0.0, glutGet(GLUT_WINDOW_WIDTH), 0.0, glutGet(GLUT_WINDOW_HEIGHT));
    
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    
    glDisable(GL_LIGHTING);
    glDisable(GL_DEPTH_TEST);
    
    glColor3f(1.0f, 1.0f, 1.0f);
    glRasterPos2f(x, y);
    
    for (const char* c = text; *c != '\0'; c++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
    }
    
    glEnable(GL_LIGHTING);
    glEnable(GL_DEPTH_TEST);
    
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
}

// Set arena size
void setArenaSize(float size) {
    arenaSize = size;
}

// Get arena size
float getArenaSize() {
    return arenaSize;
}

#endif